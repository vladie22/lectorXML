<?php return array (
  'login-register' => 'App\\Http\\Livewire\\LoginRegister',
  'nav-bar' => 'App\\Http\\Livewire\\NavBar',
  'read-xml-data' => 'App\\Http\\Livewire\\ReadXmlData',
  'show-data' => 'App\\Http\\Livewire\\ShowData',
  'show-quantity' => 'App\\Http\\Livewire\\ShowQuantity',
);