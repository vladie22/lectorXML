<div>
    <p>pan</p>
    <button wire:click="$emit('closeModal', 'hello-world')">Open Modal</button>
</div>
<?php /**PATH C:\lectorXML\XMLRead\resources\views/livewire/modal.blade.php ENDPATH**/ ?>