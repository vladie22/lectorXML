<h1>perro</h1>
<?php /**PATH C:\lectorXML\XMLRead\resources\views/perro.blade.php ENDPATH**/ ?>