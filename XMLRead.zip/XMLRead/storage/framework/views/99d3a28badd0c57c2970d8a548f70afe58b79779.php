<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>read xml</title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('read-xml-data')->html();
} elseif ($_instance->childHasBeenRendered('h2BtJYt')) {
    $componentId = $_instance->getRenderedChildComponentId('h2BtJYt');
    $componentTag = $_instance->getRenderedChildComponentTagName('h2BtJYt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('h2BtJYt');
} else {
    $response = \Livewire\Livewire::mount('read-xml-data');
    $html = $response->html();
    $_instance->logRenderedChild('h2BtJYt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
   <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH C:\lectorXML\XMLRead\resources\views/welcome.blade.php ENDPATH**/ ?>